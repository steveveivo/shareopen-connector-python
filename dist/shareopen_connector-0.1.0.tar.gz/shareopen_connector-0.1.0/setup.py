from setuptools import find_packages, setup
setup(
    name="connector-sdk-python",
    version="0.1.0",
)
